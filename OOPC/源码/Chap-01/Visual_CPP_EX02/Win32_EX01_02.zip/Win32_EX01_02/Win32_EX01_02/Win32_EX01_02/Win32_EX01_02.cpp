// Win32_EX01_02.cpp : Defines the entry point for the console application.
#include "stdafx.h"
class IA
{
public:
  virtual void init()=0;
  virtual void print_area()=0;
 };

class Circle: public IA {
private:
   virtual void init();
   virtual void print_area();
   void print_perimeter();
   double radius;
   };

void Circle::init()
       { radius = 10.5; }
void Circle::print_area()
       { printf("AC = %f\n", 3.14 * radius * radius); }
void Circle::print_perimeter()
       { printf("PC = %f\n", 2 * 3.14 * radius);  }
 
/* ----------------------------------- */
class Rectangle: public IA{
private:
   virtual void init();
   virtual void print_area();
   void print_perimeter();
   double length, width;
   };

void Rectangle::init()
  { length = 10.5;  width = 5.125; }
void Rectangle::print_area()
  { printf("AR = %f\n", length * width); }
void Rectangle::print_perimeter()
  {	printf("P = %f\n", 2*(length + width));  }
/* ------------------------------------------------- */
int _tmain(int argc, _TCHAR* argv[])
{
    IA *pc =  new Circle();
	pc->init(); 
    pc->print_area();
  
	IA *pr = new Rectangle();
    pr->init();
	pr->print_area();
 	getchar();
	return 0;
}


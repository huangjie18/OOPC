/*   light.h   */
#include "lw_oopc.h"

CLASS(Light) {	
    void (*turnOn)();
    void (*turnOff)();
  }; 


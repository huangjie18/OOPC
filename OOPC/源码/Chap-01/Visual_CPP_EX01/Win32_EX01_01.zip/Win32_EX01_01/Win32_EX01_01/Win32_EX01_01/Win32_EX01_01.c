#include "stdio.h"
#include "lw_oopc.h"
/* ----------------------------------- */
INTERFACE(IA)
{
   void (*init)(void*);
   void (*print_area)(void*);
};

CLASS(Circle) {
   IMPLEMENTS(IA);
   void (*print_perimeter)(Circle*);
   double radius;
   };
static void init_circle(Circle *t){
 { t->radius = 10.5; }
}
static void pr_area_circle(Circle *t)
{ printf("AC = %f\n", 3.14 * t->radius * t->radius); }
static void pr_perimeter_circle(Circle *t) {
	printf("PC = %f\n", 2 * 3.14 * t->radius);
}
CTOR(Circle)
   FUNCTION_SETTING(IA.init, init_circle)
   FUNCTION_SETTING(IA.print_area, pr_area_circle)
   FUNCTION_SETTING(print_perimeter, pr_perimeter_circle)
END_CTOR

/* ----------------------------------- */
CLASS(Rectangle) {
   IMPLEMENTS(IA);
   void (*print_perimeter)(Rectangle*);
   double length, width;
   };
static void init_rect(Rectangle *t){
t->length = 10.5;  t->width = 5.125; 
}
static void pr_area_rect(Rectangle *t)
{ printf("AR = %f\n", t->length * t->width); }
static void pr_perimeter_rect(Rectangle *t) {
	printf("P = %f\n", 2*(t->length + t->width));
}
CTOR(Rectangle)
   FUNCTION_SETTING(IA.init, init_rect)
   FUNCTION_SETTING(IA.print_area, pr_area_rect)
   FUNCTION_SETTING(print_perimeter, pr_perimeter_rect)
END_CTOR
/* ------------------------------------------------- */

extern void* LightNew();
void main(){
	
    IA *pc = (IA*)CircleNew();
	IA *pr = (IA*)RectangleNew();

    pc->init(pc); 
    pc->print_area(pc);
  
    pr->init(pr);
	pr->print_area(pr);
 	getchar();    return;
} 
